﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyClassLibrary
{
    public class AccessPermission
    {
        //declare class variables
        public string FullAccess = "Unassigned";

        public void UpdateAccessPermission(string SafeguardingStatus, String CertificationStatus)
        {
            if (CertificationStatus == "I hold a valid health and safety certificate" && SafeguardingStatus == "Passed")
            {
                this.FullAccess = "Full Access";
            }
            else
            {
                this.FullAccess = "Access Pending";
            }
        }//update access for volunteers

        public void autoAssign()
        {
            this.FullAccess = "Full Access"; //to generate sample volutneers
        }

    }
    
}
