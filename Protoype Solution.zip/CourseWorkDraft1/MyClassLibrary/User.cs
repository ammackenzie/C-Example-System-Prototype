﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyClassLibrary
{
    public class User
    {

        public string Name { get; set; }
        public string Email { get; set; }
        
        public string Password { get; set; }

        public User() { }

        public User(string name, string email, string password)
        {
            this.Name = name;
            this.Email = email;
            this.Password = password;
        }
    }//end of user class

    public class Manager : User
    {
        public AccessInterface AccessType = new AccessInterface();//would determin what system features are presented

        public Manager()
        {
        }

        public Manager(string name, string email, string password)
        {
            this.Name = name;
            this.Email = email;
            this.Password = password;
            this.AccessType.ManagerAccess();//simluates system access allocation - equates to "Administrator"
        }

        public Manager(User newGPUser)
        {
            this.Name = newGPUser.Name;
            this.Email = newGPUser.Email;
            this.Password = newGPUser.Password;
            this.AccessType.ManagerAccess();//simluates system access allocation - equates to "Administrator"        }
        }
    }//end of Manager class
    public class Administrator : User
    {
        public AccessInterface AccessType = new AccessInterface();//would determine what features are presented

        public Administrator()
        {
            this.AccessType.AdministratorAccess();//simluates system access allocation - equates to "Administrator"
        }

        public Administrator(string name, string email, string password)
        {
            this.Name = name;
            this.Email = email;
            this.Password = password;
                this.AccessType.AdministratorAccess();//simluates system access allocation - equates to "Administrator"
            }

            public Administrator(User newGPUser)
        {
            this.Name = newGPUser.Name;
            this.Email = newGPUser.Email;
            this.Password = newGPUser.Password;
            this.AccessType.AdministratorAccess();//simluates system access allocation - equates to "Administrator"
        }
    }//end of Administrator class

    public class ExternalUser : User
    {
        //declare class variables
        public string UserID { get; set; }
        public string Address { get; set; }
        public string Number { get; set; }

        public ExternalUser() { }

        public ExternalUser(string name, string address, string number, string email)
        {
            this.UserID = email; //email serves for unique ID and username
            this.Name = name;
            this.Address = address;
            this.Number = number;
            this.Email = email;
        }//end of master constructor
    }//end of EternalUser class

    public class Client : ExternalUser
    {
        //class variable for Client
        public List<string> Requirements { get; set; }

        public Client() { }
        public Client(string name, string address, string number, string email, string password)
        {
            this.UserID = email; //email serves for unique ID and username
            this.Name = name;
            this.Address = address;
            this.Number = number;
            this.Email = email;
            this.Password = password;
        }
        public Client(string name, string address, string number, string email, string password, List<string> requirements)
        {
            this.UserID = email; //email serves for unique ID and username
            this.Name = name;
            this.Address = address;
            this.Number = number;
            this.Email = email;
            this.Password = password;
            this.Requirements = requirements;
        }//full constructor

        public Client(string name, string email)
        {
            this.UserID = email; //email serves for unique ID and username
            this.Name = name;
            this.Email = email;
        }//for use in visit history generation

        public Client(Client newUser)
        {
            this.UserID = newUser.Email; //email serves for unique ID and username
            this.Name = newUser.Name;
            this.Address = newUser.Address;
            this.Number = newUser.Number;
            this.Email = newUser.Email;
            this.Password = newUser.Password;
            this.Requirements = newUser.Requirements;
        }
        public Client(List<string> requirements)
        {
            this.Requirements = requirements;
        }
        public void CompleteClientDetails(List<string> requirements)
        {
            this.Requirements = requirements;
        }//for use once client has selected skill requirements

        public override string ToString()
        {
            string output = "";
            output += "Name: " + this.Name + "\n" + "Address: " + "\n" + this.Address + "\n";
            output += "Number: " + this.Number + "\n" + "Email: " + this.Email + "\n";
            output += "Password: " + this.Password + "   *PLEASE KEEP THIS CONFIDENTIAL*" + "\n";
            output += "Skill Requirements: " + string.Join(", ", this.Requirements) + "\n";

            return output;
        }

    }//end of Client Class

    public class Volunteer : ExternalUser
    {
        //declare class variables
        public List<string> Skills { get; set; }
        public string SafeGuardingStatus { get; set; }
        public string CertificationStatus { get; set; }
        public string TravelRange { get; set; }

        AccessPermission AccessPermission= new AccessPermission();//sample volunteers are assumed to have gained full access
        public Volunteer() { }
        public Volunteer(List<string> skills)
        {
            this.Skills = skills;
        }
        public Volunteer(string name, string address, string number, string email, string password)
        {
            this.UserID = email; //email serves for unique ID
            this.Name = name;
            this.Address = address;
            this.Number = number;
            this.Email = email;
            this.Password = password;
            this.AccessPermission.autoAssign(); //auto assigned access
        }

        public Volunteer(string name, string address, string number, string email, string password, List<string> skills, string safeGuardingStatus, string certificationStatus, string travelRange)
        {
            this.UserID = email; //email serves for unique ID and username
            this.Name = name;
            this.Address = address;
            this.Number = number;
            this.Email = email;
            this.Password = password;
            this.Skills = skills;
            this.SafeGuardingStatus = safeGuardingStatus;
            this.CertificationStatus = certificationStatus;
            this.TravelRange = travelRange;
            this.AccessPermission.UpdateAccessPermission(SafeGuardingStatus, certificationStatus); //will update AccessPermission to true to simulate ideal volunteer sign up

        }//master constructor

        public Volunteer(Volunteer tempVolunteer)
        {
            this.UserID = tempVolunteer.Email; //email serves for unique ID and username
            this.Name = tempVolunteer.Name;
            this.Address = tempVolunteer.Address;
            this.Number = tempVolunteer.Number;
            this.Email = tempVolunteer.Email;
            this.Password = tempVolunteer.Password;
            this.Skills = tempVolunteer.Skills;
            this.SafeGuardingStatus = tempVolunteer.SafeGuardingStatus;
            this.CertificationStatus = tempVolunteer.CertificationStatus;
            this.TravelRange = tempVolunteer.TravelRange;
            this.AccessPermission.UpdateAccessPermission(tempVolunteer.SafeGuardingStatus, tempVolunteer.CertificationStatus);
        }//copy constructor

        public Volunteer(string name, string email)
        {
            this.UserID = email; //email serves for unique ID and username
            this.Name = name;
            this.Email = email;
            this.AccessPermission.autoAssign(); //auto assigned access
        }//for use in visit history generation

        public Volunteer(string name, string email, string address, List<string> skills, string travelRange)
        {
            this.UserID = email; //email serves for unique ID and username
            this.Name = name;
            this.Email = email;
            this.Address = address;
            this.Skills = skills;
            this.TravelRange = travelRange;
            this.AccessPermission.autoAssign(); //auto assigned access

        }//for use in VisitArranger

        public Volunteer(string name, string email, string address, string password, List<string> skills, string travelRange)
        {
            this.UserID = email; //email serves for unique ID and username
            this.Name = name;
            this.Email = email;
            this.Address = address;
            this.Password = password;
            this.Skills = skills;
            this.TravelRange = travelRange;
            this.AccessPermission.autoAssign(); //auto assigned access
        }//for use in VisitArranger

        public void completeVolunteer(List<string> skills, string safeGuardingStatus, string certificationStatus, string travelRange)
        {
            this.Skills = skills;
            this.SafeGuardingStatus = safeGuardingStatus;
            this.CertificationStatus = certificationStatus;
            this.TravelRange = travelRange;
            this.AccessPermission.UpdateAccessPermission(SafeGuardingStatus, certificationStatus); //to simulate access change on sign up
        }//for use once volunteer has selected skills, certification and safeguarding status

        public string VolunteerToString()
        {
            string output = "";
            output += "Name: " + this.Name + "\n" + "Address: " + "\n" + this.Address + "\n";
            output += "Number: " + this.Number + "\n" + "Email: " + this.Email + "\n";
            output += "Password: " + this.Password + "  *PLEASE KEEP THIS CONFIDENTIAL*" + "\n";
            output += "Skills: " + string.Join(", ", this.Skills) + "\n";
            output += "Safeguarding Status: " + this.SafeGuardingStatus + "\n";
            output += "Certification Status: " + this.CertificationStatus + "\n";
            output += "Travel Range: " + this.TravelRange + "\n";
            output += "Access : " + this.AccessPermission.FullAccess;

            return output;
        }
         
        public override string ToString()
        {
            string output = "";
            output += "Volunteer: " + this.Name + ", Location: " + this.Address + ", Username: " + this.UserID;
            return output;
        }
    }//end of Volunteer class
}




