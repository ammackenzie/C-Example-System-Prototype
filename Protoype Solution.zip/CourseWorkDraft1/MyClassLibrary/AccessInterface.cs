﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyClassLibrary
{
    public class AccessInterface
    {
        //declare class variables
        public string AccessType = "Unassigned";

        public void ManagerAccess()
        {
            this.AccessType = "Manager";//simulate manager interface assignment
        }

        public void AdministratorAccess()
        {
            this.AccessType = "Administrator";//simulate manager interface assignment
        }


    }

}

