﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyClassLibrary
{
    public class Visit
    {
        //declare class variables
        public Client Client;

        public Volunteer Volunteer;
        public string VisitID { get; set; } //date, time, and client userID combined
        public string Date { get; set; }
        public string Time { get; set; }

        public Feedback ClientFeedback = new Feedback();

        public Feedback VolunteerFeedback = new Feedback();

        public Visit() { }
        public Visit(Client client, Volunteer volunteer, string date, string time, string clientFeedback, string volunteerFeedback, string photoAddress)
        {
            this.VisitID = date + client.UserID; //date and client userID combined
            this.Client = client;
            this.Volunteer = volunteer;
            this.Date = date;
            this.Time = time;
            this.ClientFeedback.CompleteFeedback(clientFeedback, photoAddress);
            this.VolunteerFeedback.CompleteFeedback(volunteerFeedback, photoAddress);
        }//full constructor 

        public Visit(Client client, Volunteer volunteer, string date, string time)
        {
            this.VisitID = date + client.UserID; //date and client userID combined
            this.Client = client;
            this.Volunteer = volunteer;
            this.Date = date;
            this.Time = time;
        }//for use in visit history generation

        public Visit(Visit tempVisit)
        {
            this.VisitID = tempVisit.VisitID; //date and client userID combined
            this.Client = tempVisit.Client;
            this.Volunteer = tempVisit.Volunteer;
            this.Date = tempVisit.Date;
            this.Time = tempVisit.Time;
            this.ClientFeedback = tempVisit.ClientFeedback;
            this.VolunteerFeedback = tempVisit.VolunteerFeedback;
        }//copy constructor

        public Feedback GetClientFeedback()
        {
            return this.ClientFeedback;
        }

        public Feedback GetVolunteerFeedback()
        {
            return this.VolunteerFeedback;
        }
    }
}
