﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyClassLibrary
{
    public class Feedback
    {
        //declare class variables
        public string UserFeedback = "Not provided";//default values
        public string PhotoAddress = "Not provided";//default values
        public Feedback() { }

        public Feedback(string userFeedback, string photourl)
        {
            this.UserFeedback = userFeedback;
            this.PhotoAddress = photourl;
        }
        public Boolean MissingFeedback() //checks if either volunteer or client has provided feedback
        {
            if(this.UserFeedback == null || this.UserFeedback == "" || this.UserFeedback == "Not provided")
            {
                return true;
            }
            else
            {
                return false;
            }
        }//end of MissingFeedback()

        public void CompleteFeedback(string userFeedback, string photourl)
        {
            this.UserFeedback = userFeedback;
            this.PhotoAddress = photourl;
        }//to complete feedback instance once user had provided feedback

    }//end of class

}
