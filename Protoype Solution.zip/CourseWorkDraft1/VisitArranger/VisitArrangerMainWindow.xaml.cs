﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace VisitArranger
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            //generate Lists needed to populate comboboxes
            List<int> Days = new List<int>();
            List<int> Months = new List<int>();
            List<int> Hours = new List<int>();
            List<int> Minutes = new List<int>(0);

            //Add relevant values to each cList
            Days.AddRange(Enumerable.Range(1, 31));
            Months.AddRange(Enumerable.Range(1, 12));
            Hours.AddRange(Enumerable.Range(1, 24));
            Minutes.Add(00);
            Minutes.Add(15);
            Minutes.Add(30);
            Minutes.Add(45);

            //populate comboboxes
            foreach (int e in Days)
            {
                comboDay.Items.Add(e);
            }

            foreach (int e in Months)
            {
                comboMonth.Items.Add(e);
            }

            foreach (int e in Hours)
            {
                comboHour.Items.Add(e);
            }

            foreach (int e in Minutes)
            {
                comboMin.Items.Add(e);
            }



        }

        private void ButtonRequest_Click(object sender, RoutedEventArgs e)
        {
            if (comboDay.SelectedIndex == -1 || comboMonth.SelectedIndex == -1 || comboHour.SelectedIndex == -1 || comboMin.SelectedIndex == -1)
            {
                lblWarning.Visibility = Visibility.Visible;
                lbl1.Visibility = Visibility.Visible;
                lbl2.Visibility = Visibility.Visible;
            }
            else
            {
                this.Close();
            }
        }
    }
}
