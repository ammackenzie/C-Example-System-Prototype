﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MyClassLibrary;
using AccessFeedback;

namespace LogIn
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 
    //**NOT IN USE - PROJECT ABSORBED BY MASTER
    public partial class LogInMainWindow : Window
    {
        List<string> requirementSamples1 = new List<string>();
        List<string> requirementSamples2 = new List<string>();
        List<Client> clientBase = new List<Client>();
        List<Volunteer> volunteerBase = new List<Volunteer>();
        Manager Manager = new Manager();
        Administrator Administrator = new Administrator();

        public LogInMainWindow()
        {
            InitializeComponent();

            clientBase = GenerateClientBase();
            volunteerBase = GenerateVolunteers();

            Manager = new Manager("Sandy Boss", "sandyBoss@GP.net", "sandygppass");
            Administrator = new Administrator("Billy Henchy", "billyHenchy@GP.net", "billygppass");

        }

        public List<Client> GenerateClientBase()
        {
            //generate some sample skills needs lists
            List<string> requirementSamples1 = new List<string>();
            requirementSamples1.Add("Grass cutting");
            requirementSamples1.Add("Weeding");
            requirementSamples1.Add("Planting");
            requirementSamples1.Add("Hedge cutting");
            requirementSamples1.Add("Tree surgery");

            List<string> requirementSamples2 = new List<string>();
            requirementSamples2.Add("Grass cutting");
            requirementSamples2.Add("Weeding");
            requirementSamples2.Add("Planting");
            requirementSamples2.Add("Hedge cutting");

            List<string> requirementSamples3 = new List<string>();
            requirementSamples3.Add("Grass cutting");
            requirementSamples3.Add("Weeding");
            requirementSamples3.Add("Planting");
            requirementSamples3.Add("Hedge cutting");
            requirementSamples3.Add("Painting");  //for testing to show no match possibility



            //generate a list of sample clients
            List<Client> clientBase = new List<Client>();
            clientBase.Add(new Client("John Hamm", "Edinburgh", "012345", "johnHamm@gmail.com", "johnpass", requirementSamples1));
            clientBase.Add(new Client("Pepe Silvia", "Edinburgh", "012346", "pepeSilvia@gmail.com", "pepepass", requirementSamples1));
            clientBase.Add(new Client("Charlie Brooker", "Bathgate", "012347", "charlieBrooker@gmail.com", "charliepass", requirementSamples2));
            clientBase.Add(new Client("Charity Constance", "Edinburgh", "012348", "charityConstance@gmail.com", "charitypass", requirementSamples3)); //skills match fail test
            clientBase.Add(new Client("Sarah Silverman", "Livingston", "012349", "sarahSilverman@gmail.com", "sarahpass", requirementSamples2));

            return clientBase;
        }

        public List<Volunteer> GenerateVolunteers()
        {
            //create a sample List of Volunteers
            List<Volunteer> Volunteers = new List<Volunteer>();

            //create sample skills lists

            List<string> skillsSamples1 = new List<string>();
            List<string> skillsSamples2 = new List<string>();


            skillsSamples1.Add("Grass cutting");
            skillsSamples1.Add("Weeding");
            skillsSamples1.Add("Planting");
            skillsSamples1.Add("Hedge cutting");
            skillsSamples1.Add("Tree surgery");

            skillsSamples2.Add("Grass cutting");
            skillsSamples2.Add("Weeding");
            skillsSamples2.Add("Planting");
            skillsSamples2.Add("Hedge cutting");

            //for reference
            /*lstTravel.Items.Add("1 - 2 Miles");
            lstTravel.Items.Add("3 - 5 Miles");
            lstTravel.Items.Add("5- 10 Miles");
            lstTravel.Items.Add("10 - 20 Miles"); - livingston
            lstTravel.Items.Add("20 - 30 Miles"); - bathgate
            */

            Volunteers.Add(new Volunteer("Deborah Barnard", "deborahBarnard@gmail.com", "Edinburgh", "deborahpass", skillsSamples1, "1 - 2 Miles"));
            Volunteers.Add(new Volunteer("Billy Bobb", "billyBobb@gmail.com", "Bathgate", "billypass", skillsSamples2, "3 - 5 Miles"));//bathgate only
            Volunteers.Add(new Volunteer("Bobby McFarlane", "bobbyMcfarlane@gmail.com", "Bathgate", "bobbypass", skillsSamples2, "20 - 30 Miles")); //all
            Volunteers.Add(new Volunteer("Lilly Lavish", "lillyLavish@gmail.com", "Livingston", "lillypass", skillsSamples1, "1 - 2 Miles")); //livingston only
            Volunteers.Add(new Volunteer("Leslie Johnson", "Leslie Johnson@gmail.com", "Livingston", "lesliepass", skillsSamples2, "20 - 30 Miles"));//all
            Volunteers.Add(new Volunteer("Elijah Wood", "elijahWood@gmail.com", "Edinburgh", "elijahpass", skillsSamples1, "10 - 20 Miles"));//Edinburgh and livingston
            Volunteers.Add(new Volunteer("Connie Wringe", "connieWringe@gmail.com", "Edinburgh", "conniepass", skillsSamples1, "1-2 Miles"));//Edinburgh only
            return Volunteers;
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string username = inputUsername.Text;
            string password = inputPassword.Text;



            foreach (Client tempClient in clientBase)
            {
                if (tempClient.Email == username)
                {
                    if(tempClient.Password == password)
                    {
                        ConfirmationWindowGlobal newWin = new ConfirmationWindowGlobal(tempClient);
                        newWin.Show();
                        this.Close();
                    }
                }else
                {
                    lblError.Visibility = Visibility.Visible;
                    lbl1.Visibility = Visibility.Visible;
                    lbl2.Visibility = Visibility.Visible;
                }
            }

            foreach (Volunteer tempVolunteer in volunteerBase)
            {
                if (tempVolunteer.Email == username)
                {
                    if (tempVolunteer.Password == password)
                    {
                        ConfirmationWindowGlobal newWin = new ConfirmationWindowGlobal(tempVolunteer);
                        newWin.Show();
                        this.Close();
                    }
                }
                else
                {
                    lblError.Visibility = Visibility.Visible;
                    lbl1.Visibility = Visibility.Visible;
                    lbl2.Visibility = Visibility.Visible;
                }
            }

            if(username == Manager.Email && password == Manager.Password)
            {
                //success
            } else if (username == Administrator.Email && password == Administrator.Password)
            {
                //sucess
            } else
            {
                lblError.Visibility = Visibility.Visible;
                lbl1.Visibility = Visibility.Visible;
                lbl2.Visibility = Visibility.Visible;
            }





            //ClientConfirmationWindow newWin2 = new ClientConfirmationWindow();
            // newWin2.Show();
            //this.Close();



        }
    }
}
