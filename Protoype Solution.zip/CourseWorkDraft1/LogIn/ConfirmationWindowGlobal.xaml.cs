﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MyClassLibrary;

namespace LogIn
{
    /// <summary>
    /// Interaction logic for confirmationWindow.xaml
    /// </summary>
    public partial class ConfirmationWindowGlobal : Window
    {
        //declare class-wide object instances
        Client LoggedInClient = new Client();
        Volunteer LoggedInVolunteer = new Volunteer();
        public ConfirmationWindowGlobal(Client Client)
        {
            InitializeComponent();
            LoggedInClient = Client;
            lblWelcome.Content = "Hello " + LoggedInClient.Name + "." + "\n" + "What would you like to do?";
            buttonRequest.Content = "Request Visit";
      
        }//Client view

        public ConfirmationWindowGlobal(Volunteer Volunteer)
        {
            InitializeComponent();
            LoggedInVolunteer = Volunteer;
            lblWelcome.Content = "Hello " + LoggedInVolunteer.Name + "." + "\n" + "What would you like to do?";
            buttonRequest.Content = "Accept Visit Request";
        }//Volunteer view


        private void ButtonRequest_Click(object sender, RoutedEventArgs e)
        {
            if(LoggedInClient.UserID != null)
            {
                VisitArranger newWin = new VisitArranger(LoggedInClient);
                newWin.Show();
                this.Close();

            } else
            {
                VolunteerView newWin = new VolunteerView(LoggedInVolunteer);
                newWin.Show();
                this.Close();
            }
            
        }//end of button click handler
    }//end of window class
}
