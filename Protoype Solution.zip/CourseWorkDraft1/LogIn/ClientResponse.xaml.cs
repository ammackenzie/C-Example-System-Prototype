﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MyClassLibrary;

namespace LogIn
{
    /// <summary>
    /// Interaction logic for ClientResponse.xaml
    /// </summary>
    public partial class ClientResponse : Window
    {
        //declare some class-wide object instances
        Client LoggedInClient = new Client();
        Volunteer SelectedVolunteer = new Volunteer();
        string visitDetails = "";
        public ClientResponse(string details, Client Client, Volunteer Volunteer)
        {
            InitializeComponent();
            LoggedInClient = Client;
            SelectedVolunteer = Volunteer;
            visitDetails = details;
            lblOutput.Content = visitDetails;
            //displays full Visit details
            lblDisplay.Content = "Great news! Our volunteer " + SelectedVolunteer.Name + "\n" + "is available to attend your requested visit";

        }

        private void ButtonExit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void ButtonRearrange_Click(object sender, RoutedEventArgs e)
        {
            VisitArranger newWin = new VisitArranger(LoggedInClient);
            newWin.Show();
            this.Close();
        }

        private void ButtonConfirm_Click(object sender, RoutedEventArgs e)
        {
            ClientFinalWindow newWin = new ClientFinalWindow();
            newWin.Show();
            this.Close();
        }
    }//end of window class
}
