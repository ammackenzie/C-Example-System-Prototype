﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MyClassLibrary;

namespace LogIn
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class VisitArranger : Window
    {
        Client LoggedInClient = new Client(); //create a temp Client object
        public VisitArranger(Client Client)//client view
        {
            InitializeComponent();
            LoggedInClient = Client; //assign details of logged in client to our temp Client


            //generate Lists needed to populate comboboxes
            List<int> Days = new List<int>();
            List<int> Months = new List<int>();
            List<int> Hours = new List<int>();
            List<string> Minutes = new List<string>(0);

            //Add relevant values to each cList
            Days.AddRange(Enumerable.Range(1, 31));
            Months.AddRange(Enumerable.Range(1, 12));
            Hours.AddRange(Enumerable.Range(1, 24));
            Minutes.Add("00");
            Minutes.Add("15");
            Minutes.Add("30");
            Minutes.Add("45");

            //populate comboboxes
            foreach (int e in Days)
            {
                comboDay.Items.Add(e);
            }

            foreach (int e in Months)
            {
                comboMonth.Items.Add(e);
            }

            foreach (int e in Hours)
            {
                comboHour.Items.Add(e);
            }

            foreach (string s in Minutes)
            {
                comboMin.Items.Add(s);
            }

        }//constructor for clients

        public List<Volunteer> GenerateVolunteers()
        {
            //create a sample List of Volunteers
            List<Volunteer> Volunteers = new List<Volunteer>();

            //create sample skills lists

            List<string> skillsSamples1 = new List<string>();
            List<string> skillsSamples2 = new List<string>();


            skillsSamples1.Add("Grass cutting");
            skillsSamples1.Add("Weeding");
            skillsSamples1.Add("Planting");
            skillsSamples1.Add("Hedge cutting");
            skillsSamples1.Add("Tree surgery");

            skillsSamples2.Add("Grass cutting");
            skillsSamples2.Add("Weeding");
            skillsSamples2.Add("Planting");
            skillsSamples2.Add("Hedge cutting");

            Volunteers.Add(new Volunteer("Deborah Barnard", "deborahBarnard@gmail.com", "Edinburgh", skillsSamples1, "1 - 2 Miles"));
            Volunteers.Add(new Volunteer("Billy Bobb", "billyBobb@gmail.com", "Bathgate", skillsSamples2, "3 - 5 Miles"));//bathgate only
            Volunteers.Add(new Volunteer("Bobby McFarlane", "bobbyMcfarlane@gmail.com", "Bathgate", skillsSamples2, "20 - 30 Miles")); //all
            Volunteers.Add(new Volunteer("Lilly Lavish", "lillyLavish@gmail.com", "Livingston", skillsSamples1, "1 - 2 Miles")); //livingston only
            Volunteers.Add(new Volunteer("Leslie Johnson", "Leslie Johnson@gmail.com", "Livingston", skillsSamples2, "20 - 30 Miles"));//all
            Volunteers.Add(new Volunteer("Elijah Wood", "elijahWood@gmail.com", "Edinburgh", skillsSamples1, "10 - 20 Miles"));//Edinburgh and livingston
            Volunteers.Add(new Volunteer("Connie Wringe", "connieWringe@gmail.com", "Edinburgh", "conniepass", skillsSamples1, "1-2 Miles"));//Edinburgh only

            return Volunteers;//returns a list of pre-generated volunteers
        }



        public List<Volunteer> ClientToVolunteerMatch(Client Client)
        {
            List<Volunteer> Volunteers = GenerateVolunteers();
            List<Volunteer> SuitableVolunteers = new List<Volunteer>();
            foreach(Volunteer v in Volunteers)
            {
                //if statement checks if client is within volunteers travel range and if the volunteer skills match the client requirements
                if ((v.Address == Client.Address || v.TravelRange == "20 - 30 Miles") && (v.Skills.SequenceEqual(Client.Requirements) || Client.Requirements.Intersect(v.Skills).Any())) //checks if location map AND skills and requirements match
                {
                    SuitableVolunteers.Add(v);
                }
            }

            return SuitableVolunteers;//returns a list of the volunteers that have the right skillset and are within travel range
        }



        private void ButtonRequest_Click(object sender, RoutedEventArgs e)
        {
            if (comboDay.SelectedIndex == -1 || comboMonth.SelectedIndex == -1 || comboHour.SelectedIndex == -1 || comboMin.SelectedIndex == -1)
            {
                lblWarning.Visibility = Visibility.Visible;
                lbl1.Visibility = Visibility.Visible;
                lbl2.Visibility = Visibility.Visible;
            }//triggers if required boxes are not all selected
            else
            {
                //populate details string with requested date and time
                string details = "";
                details += "Date: " + comboDay.SelectedValue.ToString() + "/" + comboMonth.SelectedValue.ToString();
                details += "\n" + "Time: " + comboHour.SelectedValue.ToString() + ":" + comboMin.SelectedValue.ToString();

                List<Volunteer> SuitableVolunteers = ClientToVolunteerMatch(LoggedInClient);//generate a list of Volunteers that match requesting Client's skills requirements and location

                SystemMatched newWin = new SystemMatched(SuitableVolunteers, LoggedInClient, details);
                newWin.Show();
                this.Close();
            }
        }//end of button click handler
    }//end of window class
}
