﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MyClassLibrary;


namespace LogIn
{
    /// <summary>
    /// Interaction logic for SystemMatched.xaml
    /// </summary>
    public partial class SystemMatched : Window
    {
        //declare some class-wide instance objects for use
        Client LoggedInClient = new Client();
        List<Volunteer> SuitableVolunteers = new List<Volunteer>();
        string visitdetails = "";
        public SystemMatched(List<Volunteer> Volunteers, Client Client, string details) //window simulates what system will do automatically or what early system will allow clients to select
        {
            InitializeComponent();
            
            //hide error elements
            borderExit.Visibility = Visibility.Hidden;
            buttonExit.Visibility = Visibility.Hidden;
            txtWarning.Visibility = Visibility.Hidden;

            SuitableVolunteers = Volunteers;
      
            LoggedInClient = Client;
            visitdetails = details;

            if (!SuitableVolunteers.Any())
            {

                //display error saying no match and button to leave
                comboVolunteers.Visibility = Visibility.Hidden;
                buttonRequest.Visibility = Visibility.Hidden;
                buttonExit.Visibility = Visibility.Visible;
                txtWarning.Visibility = Visibility.Visible;
            }
            else
            {
                foreach (Volunteer V in SuitableVolunteers)
                {
                    comboVolunteers.Items.Add(ListVolunteerDetails(V));
                    comboVolunteers.SelectedIndex = 0;
                }//populates combobox with the suitable volunteers

            }

        }//end of constructor

        public string ListVolunteerDetails(Volunteer Volunteer)
        {
            string output = "";

            output += "Volunteer: " + Volunteer.Name + ", Location: " + Volunteer.Address;

            return output;
        }//for display in combobox

        private void buttonRequest_Click(object sender, RoutedEventArgs e)
        {

            string selected = comboVolunteers.SelectedValue.ToString();
            Volunteer SelectedVolunteer = new Volunteer();

            foreach(Volunteer V in SuitableVolunteers)
            {
                if(ListVolunteerDetails(V) == selected){
                    SelectedVolunteer = V;
                }
            }//finds the selected volunteer from the list of suitable volunteers

            VolunteerView newWin = new VolunteerView(visitdetails, LoggedInClient, SelectedVolunteer);
            newWin.Show();

            this.Close();
        }//end of butotn click handler

        private void buttonExit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }//end of window class
}
