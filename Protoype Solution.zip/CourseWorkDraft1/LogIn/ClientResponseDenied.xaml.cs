﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MyClassLibrary;


namespace LogIn
{
    /// <summary>
    /// Interaction logic for ClientResponseDenied.xaml
    /// </summary>
    public partial class ClientResponseDenied : Window
    {
        //declare a class-wide Client object
        Client LoggedInClient = new Client();
        public ClientResponseDenied(string details, Client Client)
        {
            InitializeComponent();
            lblOutput.Content = details;
            LoggedInClient = Client;
        }

        private void ButtonRearrange_Click(object sender, RoutedEventArgs e)
        {
            VisitArranger newWin = new VisitArranger(LoggedInClient);
            newWin.Show();
            this.Close();
        }

        private void ButtonExit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }//end of window class
}
