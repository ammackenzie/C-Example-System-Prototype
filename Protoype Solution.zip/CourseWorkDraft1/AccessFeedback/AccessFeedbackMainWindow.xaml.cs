﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MyClassLibrary;


namespace AccessFeedback
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class AccessFeedbackMainWindow : Window
    {
        public AccessFeedbackMainWindow()
        {
            InitializeComponent();
        }

        public AccessFeedbackMainWindow(Manager Manager) //manager view with tailored welcome message
        {
            InitializeComponent();
            lblWelcome.Content = "Welcome, Manager " + Manager.Name + ".\n" + "What would you like to access?";//tailored
        }

        public AccessFeedbackMainWindow(Administrator Administrator)//Administrator view with tailored welcome message
        {
            InitializeComponent();
            lblWelcome.Content = "Welcome, Administrator " + Administrator.Name + ".\n" + "What would you like to access?";//tailored
        }

        private void buttonView_Click(object sender, RoutedEventArgs e)
        {
            GPVisitHistory newWin = new GPVisitHistory();
            newWin.Show();
            this.Close();
        }//offers same interface for both
    }//end of window class
}
