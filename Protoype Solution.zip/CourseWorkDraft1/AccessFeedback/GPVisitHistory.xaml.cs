﻿using MyClassLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AccessFeedback
{
    /// <summary>
    /// Interaction logic for VisitHistory.xaml
    /// </summary>
    public partial class GPVisitHistory : Window
    {
        //create class wide visit list
        List<Visit> VisitList = new List<Visit>();
        public GPVisitHistory()
        {
            InitializeComponent();
            //generate sample client and volunteers
            Client Client1 = new Client("John Hamm", "johnHamm@gmail.com");
            Client Client2 = new Client("Sarah Silverman", "sarahSilverman@gmail.com");

            Volunteer Volunteer1 = new Volunteer("Todd Bricks", "toddBricks@gmail.com");
            Volunteer Volunteer2 = new Volunteer("Bridgget Tammy", "bridgettTammy@gmail.com");
            Volunteer Volunteer3 = new Volunteer("Billy Bob", "billyBob@gmail.com");
            Volunteer Volunteer4 = new Volunteer("Connie Wringe", "connieWringe@gmail.com");



            //generate some sample visit instances
            string photo = "/Photos/1234.jpg";
            string photo2 = "/Photos/1235.jpg";

            Visit Visit1 = new Visit(Client1, Volunteer1, "12/11/19", "10:45", "Great Performance, good chat", "Client was friendly and accomodating", photo);
            Visit Visit2 = new Visit(Client1, Volunteer2, "14/11/19", "10:45", "Some good moments from volunteer!", "Not provided", photo2);
            Visit Visit3 = new Visit(Client1, Volunteer1, "15/11/19", "11:45");
            Visit Visit4 = new Visit(Client2, Volunteer3, "10/10/19", "12:00", "Not provided", "Client gave me tea", "Not provided");
            Visit Visit5 = new Visit(Client2, Volunteer4, "08/10/19", "12:30");

            //add visits to list
            VisitList.Add(Visit1);
            VisitList.Add(Visit2);
            VisitList.Add(Visit3);
            VisitList.Add(Visit4);
            VisitList.Add(Visit5);

            string detailsString = "";
   
            foreach (Visit V in VisitList)
            {
                detailsString += (VisitToString(V));
                detailsString += "\n";

            }//populate details into history label

            scrollHistory.Content = detailsString;

            //populate feedback label with visits requiring feedback
            string feedbackVisits = "";

            foreach (Visit V in VisitList)
            {
                if (!V.ClientFeedback.MissingFeedback() || !V.VolunteerFeedback.MissingFeedback())//if the visit has any feedback
                {
                    feedbackVisits += VisitToString(V);
                    feedbackVisits += "\n";
                    comboFeedbackVisits.Items.Add(VisitStringList(V)); //add list version to comboBox
                }
            }//from sample Visits selects the Visits that have at least one feedback instance

            comboFeedbackVisits.SelectedIndex = 0;

            scrollHistoryFeedback.Content = feedbackVisits;//displays details of visits with any feedback

        }//end of constructor
        public string VisitToString(Visit Visit)
        {
            string output = "";

            output += "\nClient: " + Visit.Client.Name + "\n";
            output += "Client userID: \n" + Visit.Client.UserID + "\n";
            output += "Volunteer: " + Visit.Volunteer.Name + "\n";
            output += "Volunteer userID: \n" + Visit.Volunteer.UserID + "\n";
            output += "Date: " + Visit.Date + ", Time: " + Visit.Time + "\n";
            output += "Client Feedback: \n" + Visit.ClientFeedback.UserFeedback +"\n";
            output += "Client Photo: \n" + Visit.ClientFeedback.PhotoAddress + "\n";
            output += "Volunteer Feedback: \n" + Visit.VolunteerFeedback.UserFeedback + "\n";
            output += "Volunteer Photo: \n" + Visit.VolunteerFeedback.PhotoAddress + "\n_________________________________________";

            return output;
        }//tailored to show userIDs for GPUser view

        public string VisitStringList(Visit Visit)
        {
            string output = "";

            output += "Visit with " + Visit.Volunteer.Name + " on " + Visit.Date;

            return output;
        }//for display in combobox

        private void buttonView_Click(object sender, RoutedEventArgs e)
        {
            string selectedVisit = comboFeedbackVisits.SelectedValue.ToString();//store selected value from combobox

            Visit TempVisit = new Visit();

            foreach (Visit V in VisitList)
            {
                if (selectedVisit.Contains(V.Volunteer.Name) && selectedVisit.Contains(V.Date))
                {
                    TempVisit = V;
                }
            }//ensures that correct feedback is selected from list based on combo selection

            FeedbackView newWin = new FeedbackView(TempVisit);
            newWin.Show();
        }//end of button click handler

        private void buttonExit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }//end of window class
}
