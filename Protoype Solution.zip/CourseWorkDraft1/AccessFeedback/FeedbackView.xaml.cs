﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MyClassLibrary;


namespace AccessFeedback
{
    /// <summary>
    /// Interaction logic for FeedbackView.xaml
    /// </summary>
    public partial class FeedbackView : Window
    {
        public FeedbackView(Visit Visit)
        {
            InitializeComponent();

            //display the details of input Feedback
            scrollDetails.Content = VisitToString(Visit);//displays full details

            lblFeedback.Content = VisitFeedbackOnly(Visit);//displays just feedback
        }

        public string VisitToString(Visit Visit)
        {
            string output = "";

            output += "Client: " + Visit.Client.Name + "\n";
            output += "Client userID: " + Visit.Client.UserID + "\n";
            output += "Volunteer: " + Visit.Volunteer.Name + "\n";
            output += "Volunteer userID: " + Visit.Volunteer.UserID + "\n";
            output += "Date: " + Visit.Date + ", Time: " + Visit.Time + "\n";
            output += "Client Feedback: \n" + Visit.ClientFeedback.UserFeedback + "\n";
            output += "Client Photo: \n" + Visit.ClientFeedback.PhotoAddress + "\n";
            output += "Volunteer Feedback: \n" + Visit.VolunteerFeedback.UserFeedback + "\n";
            output += "Volunteer Photo: \n" + Visit.VolunteerFeedback.PhotoAddress + "\n";

            return output;
        }//tailored to show userIDs for GPUser view

        public string VisitFeedbackOnly(Visit Visit)
        {
            string output = "";

            output += "Client Feedback: \n" + Visit.ClientFeedback.UserFeedback + "\n";
            output += "Client Photo: \n" + Visit.ClientFeedback.PhotoAddress + "\n";
            output += "Volunteer Feedback: \n" + Visit.VolunteerFeedback.UserFeedback + "\n";
            output += "Volunteer Photo: \n" + Visit.VolunteerFeedback.PhotoAddress + "\n";

            return output;
        }//returns just the feedback from a Visit

        private void buttonDownload_Click(object sender, RoutedEventArgs e)
        {
            lblDownloaded.Visibility = Visibility.Visible; //alert that download has completed
        }

        private void buttonReturn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
