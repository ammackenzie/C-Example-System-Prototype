﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CourseWorkDraft1;
using MyClassLibrary;
using SignUp;


namespace SignUp
{
    /// <summary>
    /// Interaction logic for SignUp2.xaml
    /// </summary>
    public partial class SignUp2 : Window
    {

        User newUser2 = new User();
        public SignUp2(User newUser)
        {
            InitializeComponent();
            //populate gardening skills options
            lstSkills.Items.Add("Grass cutting");
            lstSkills.Items.Add("Weeding");
            lstSkills.Items.Add("Planting");
            lstSkills.Items.Add("Hedge cutting");
            lstSkills.Items.Add("Tree surgery");

            lstSkills.SelectionMode = SelectionMode.Multiple;

            lstType.Items.Add("Client");
            lstType.Items.Add("Volunteer");

            newUser2.updateUser(newUser);
            
        }

        private void buttonRegister_Click(object sender, RoutedEventArgs e)
        {
            //save selected skills into new string array
            List<string> skills = new List<string>();

            foreach (var i in lstSkills.SelectedItems)
            {
                skills.Add(i.ToString());
            }


            //clear skills box
            lstSkills.SelectedItems.Clear();

            //save selected user type as a new string
            string type = lstType.SelectedValue.ToString();

            //finalise Userdetails
            newUser2.finaliseUser(skills, type);

            DisplayDetails newWin = new DisplayDetails(newUser2);
            newWin.Show();
            
        }
    }
}
