﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MyClassLibrary;

namespace Prototype40091970
{
    /// <summary>
    /// Interaction logic for VolunteerWindow.xaml
    /// </summary>
    public partial class VolunteerWindow : Window
    {
        //create class wide Volunteer object 
        Volunteer TempVolunteer = new Volunteer();
        public VolunteerWindow(Volunteer newVolunteer)
        {
            InitializeComponent();
            //populate gardening skills options
            lstSkills.Items.Add("Grass cutting");
            lstSkills.Items.Add("Weeding");
            lstSkills.Items.Add("Planting");
            lstSkills.Items.Add("Hedge cutting");
            lstSkills.Items.Add("Tree surgery");

            lstSkills.SelectedIndex = 0;

            lstSkills.SelectionMode = SelectionMode.Multiple;//allow for multiple skills to be selected
            //Populate certification options
            lstCertification.Items.Add("I hold a valid health and safety certificate");
            lstCertification.Items.Add("I am willing to apply for a health and safety certificate");
            lstCertification.Items.Add("I need to renew my health and safety certificate");
            lstCertification.SelectedIndex = 0;

            //populate travel range options
            lstTravel.Items.Add("1 - 2 Miles");
            lstTravel.Items.Add("3 - 5 Miles");
            lstTravel.Items.Add("5- 10 Miles");
            lstTravel.Items.Add("10 - 20 Miles");
            lstTravel.Items.Add("20 - 30 Miles");
            lstTravel.SelectedIndex = 0;

            TempVolunteer = newVolunteer;
        }//end of constructor

        private void ButtonSubmit_Click(object sender, RoutedEventArgs e)
        {
            if(checkAgree.IsChecked == false)
            {
                lblWarning.Visibility = Visibility.Visible;
            }//triggers if agreement box not checked
            else
            {
                List<string> skills = new List<string>();
                foreach (var i in lstSkills.SelectedItems)
                {
                    skills.Add(i.ToString());
                } //stores selected skills
                string safeguarding = "Passed"; //**for purposes of prototype sample volunteers are auto-passed**
                string certification = lstCertification.SelectedValue.ToString();
                string travelRange = lstTravel.SelectedValue.ToString();

                TempVolunteer.completeVolunteer(skills, safeguarding, certification, travelRange);

                Volunteer CompleteVolunteer = new Volunteer(TempVolunteer);//make a new complete volunteer object for storage

                ThankYouWindow newWin = new ThankYouWindow(CompleteVolunteer);//pass string representation of completeVolunteer to next window
                newWin.Show();
                this.Close();
            }//end of if/else statement
        }//end of button click hander
    }//end of window class
}
