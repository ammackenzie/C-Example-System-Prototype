﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Prototype40091970;
using MyClassLibrary;


namespace SignUp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class SignUpMainWindow : Window
    {
        public SignUpMainWindow()
        {
            InitializeComponent();
            lblWarning.Visibility = Visibility.Hidden;
            lbl1.Visibility = Visibility.Hidden;
            lbl2.Visibility = Visibility.Hidden;
            lbl3.Visibility = Visibility.Hidden;
            //populate choicebox
            choiceBox.Items.Add("Client");
            choiceBox.Items.Add("Volunteer");
            choiceBox.SelectedIndex = 0;
        }

        public void ClearForms()//method to clear input boxes
        {
            inputName.Clear();
            inputAddress1.Clear();
            inputAddress2.Clear();
            inputNumber.Clear();
            inputEmail.Clear();
            inputPassword.Clear();
        }//end of clearForms

        public Boolean ValidateForms()
        {

            var entries = new[] { inputName, inputAddress1, inputPostcode, inputNumber, inputPassword};
            //foreach(var entry in entries.Where<entry => String.IsNullOrEmpty(entry.Text) >;

            if (entries.Any(t => string.IsNullOrEmpty(t.Text)))
            {
                return true;
            }
            else
            {
                return false;
            }//checks input of each required box and returns false if any not filled in
            
        }//end of validateForms

        public void displayError()
        {
            lblWarning.Visibility = Visibility.Visible;
            lbl1.Visibility = Visibility.Visible;
            lbl2.Visibility = Visibility.Visible;
            lbl3.Visibility = Visibility.Visible;
        }
        private void buttonNext_Click(object sender, RoutedEventArgs e)
        {
            //if(String.IsNullOrEmpty())

            if (ValidateForms())
            {
                displayError(); //shows error boxes
            } else
            {
                //store name in a variable
                string name = inputName.Text;

                //combine address values in one variable 
                string address = inputAddress1.Text + "\n" + inputAddress2.Text + "\n" + inputPostcode.Text;

                //store contact number in a variable
                string number = inputNumber.Text;

                //store email address in a variable
                string email = inputEmail.Text;

                //store password in a variable
                string password = inputPassword.Text;

                //determine choice
                string choice = choiceBox.SelectedValue.ToString();

                //create branch to determine which window to display based on choice

                if(choice == "Client")
                {
                    Client newClient = new Client(name, address, number, email, password);//create new client
                    ClientWindow newWin = new ClientWindow(newClient);//pass new client to client window
                    newWin.Show();//open new window

                } else if (choice == "Volunteer")
                {
                    Volunteer newVolunteer = new Volunteer(name, address, number, email, password);//create new volunteer
                    VolunteerWindow newWin = new VolunteerWindow(newVolunteer);// pass new volunteer to volunteer window
                    newWin.Show();
                }

            }//end of if/else statements
        }//end of button click handler
    }//end of window class

}

   