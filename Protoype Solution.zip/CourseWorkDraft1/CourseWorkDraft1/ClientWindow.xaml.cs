﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MyClassLibrary;
using Prototype40091970;

namespace SignUp
{
    /// <summary>
    /// Interaction logic for ClientWindow.xaml
    /// </summary>
    public partial class ClientWindow : Window
    {
        //create class-wide Client object
        Client TempClient = new Client();
        public ClientWindow(Client NewClient)
        {
            InitializeComponent();
            //populate gardening skills requirements options
            lstSkills.Items.Add("Grass cutting");
            lstSkills.Items.Add("Weeding");
            lstSkills.Items.Add("Planting");
            lstSkills.Items.Add("Hedge cutting");
            lstSkills.Items.Add("Tree surgery");
            lstSkills.SelectedIndex = 0;
            lstSkills.SelectionMode = SelectionMode.Multiple;
            TempClient = NewClient;
        }

        private void buttonRegister_Click(object sender, RoutedEventArgs e)
        {
            //save selected skills into new string array
            List<string> SkillNeeds = new List<string>();

            foreach (var i in lstSkills.SelectedItems)
            {
                SkillNeeds.Add(i.ToString());
            }

            //complete details of client
            TempClient.CompleteClientDetails(SkillNeeds);

            //store complete details in new client object for storage
            Client CompleteClient = new Client(TempClient);

            //clear skills box
            lstSkills.SelectedItems.Clear();
            ThankYouWindow newWin = new ThankYouWindow(CompleteClient);
            newWin.Show();
            this.Close();
        }//end of button click handler
    }//end of window class
}
