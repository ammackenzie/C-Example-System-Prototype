﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MyClassLibrary;

namespace Prototype40091970
{
    /// <summary>
    /// Interaction logic for ThankYouWindow.xaml
    /// </summary>
    public partial class ThankYouWindow : Window
    {
        public ThankYouWindow(Volunteer Volunteer)//volunteer view
        {
            InitializeComponent();

            lblDisplay.Content = Volunteer.VolunteerToString(); //displays the details that have been passed through
        }

        public ThankYouWindow(Client Client)//client view
        {
            InitializeComponent();

            lblDisplay.Content = Client.ToString(); //displays the details that have been passed through
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }//end of window class
}
