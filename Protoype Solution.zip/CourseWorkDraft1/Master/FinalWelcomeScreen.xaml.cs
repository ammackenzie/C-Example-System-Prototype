﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MyClassLibrary;
using LogIn;
using ProvideFeedback;
using AccessFeedback;

namespace Master
{
    /// <summary>
    /// Interaction logic for FinalWelcomeScreen.xaml
    /// </summary>
    public partial class FinalWelcomeScreen : Window
    {
        Client LoggedInClient = new Client();
        Volunteer LoggedInVolunteer = new Volunteer();
        public FinalWelcomeScreen(Client Client)
        {
            InitializeComponent();
            LoggedInClient = Client;
            lblWelcome.Content = "Hello " + LoggedInClient.Name + "." + "\n" + "What would you like to do?";//tailored content
            buttonRequest.Content = "Request Visit";

        }//case if client is logged in

        public FinalWelcomeScreen(Volunteer Volunteer)
        {
            InitializeComponent();
            LoggedInVolunteer = Volunteer;
            lblWelcome.Content = "Hello " + LoggedInVolunteer.Name + "." + "\n" + "What would you like to do?";//tailored content
            buttonRequest.Content = "Accept Visit Request";
        }//case if volunteer is logged in

        private void ButtonRequest_Click(object sender, RoutedEventArgs e)
        {
            if (LoggedInClient.UserID != null)
            {
                VisitArranger newWin = new VisitArranger(LoggedInClient);
                newWin.Show();
            }//triggers if a client is logged in
            else
            {
                VolunteerView newWin = new VolunteerView(LoggedInVolunteer);
                newWin.Show();
            }//triggers if a volunteer is logged in

        }

        private void ButtonHistory_Click(object sender, RoutedEventArgs e)
        {
            if (LoggedInClient.UserID != null)
            {
                VisitHistory newWin = new VisitHistory(LoggedInClient);
                newWin.Show();
            }//triggers if a client is logged in
            else
            {
                VisitHistory newWin = new VisitHistory(LoggedInVolunteer);
                newWin.Show();
            }//triggers if a volunteer is logged in
            
        }
    }
}
