﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MyClassLibrary;
using ProvideFeedback;
using LogIn;
using AccessFeedback;
using SignUp;
using Prototype40091970;

namespace Master
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MasterMainWindow : Window
    {
        List<Client> ClientBase = new List<Client>();
        List<Volunteer> VolunteerBase = new List<Volunteer>();
        Manager Manager = new Manager();
        Administrator Administrator = new Administrator();

        public MasterMainWindow()
        {
            InitializeComponent();

            //create autorised userbase
            ClientBase = GenerateClientBase();
            VolunteerBase = GenerateVolunteers();

            Manager = new Manager("Sandy Boss", "sandyBoss@GP.net", "sandygppass");
            Administrator = new Administrator("Billy Henchy", "billyHenchy@GP.net", "billygppass");

        }

        public List<Client> GenerateClientBase()
        {
            //generate some sample skills needs lists
            List<string> requirementSamples1 = new List<string>();
            requirementSamples1.Add("Grass cutting");
            requirementSamples1.Add("Weeding");
            requirementSamples1.Add("Planting");
            requirementSamples1.Add("Hedge cutting");
            requirementSamples1.Add("Tree surgery");

            List<string> requirementSamples2 = new List<string>();
            requirementSamples2.Add("Grass cutting");
            requirementSamples2.Add("Weeding");
            requirementSamples2.Add("Planting");
            requirementSamples2.Add("Hedge cutting");

            List<string> requirementSamples3 = new List<string>();
            requirementSamples2.Add("Grass cutting");
            requirementSamples2.Add("Weeding");
            requirementSamples2.Add("Planting");
            requirementSamples2.Add("Hedge cutting"); 
            requirementSamples3.Add("Painting");
            //for testing to show no match possibility


            //generate a list of sample clients
            List<Client> clientBase = new List<Client>();
            clientBase.Add(new Client("John Hamm", "Edinburgh", "012345", "johnHamm@gmail.com", "johnpass", requirementSamples1));
            clientBase.Add(new Client("Pepe Silvia", "Edinburgh", "012346", "pepeSilvia@gmail.com", "pepepass", requirementSamples1));
            clientBase.Add(new Client("Charlie Brooker", "Bathgate", "012347", "charlieBrooker@gmail.com", "charliepass", requirementSamples2));
            clientBase.Add(new Client("Charity Constance", "Edinburgh", "012348", "charityConstance@gmail.com", "charitypass", requirementSamples3));//for no match testing
            clientBase.Add(new Client("Sarah Silverman", "Livingston", "012349", "sarahSilverman@gmail.com", "sarahpass", requirementSamples2));

            return clientBase;
        }

        public List<Volunteer> GenerateVolunteers()
        {
            //create a sample List of Volunteers
            List<Volunteer> Volunteers = new List<Volunteer>();

            //create sample skills lists

            List<string> skillsSamples1 = new List<string>();
            List<string> skillsSamples2 = new List<string>();


            skillsSamples1.Add("Grass cutting");
            skillsSamples1.Add("Weeding");
            skillsSamples1.Add("Planting");
            skillsSamples1.Add("Hedge cutting");
            skillsSamples1.Add("Tree surgery");

            skillsSamples2.Add("Grass cutting");
            skillsSamples2.Add("Weeding");
            skillsSamples2.Add("Planting");
            skillsSamples2.Add("Hedge cutting");



            //for reference
            /*lstTravel.Items.Add("1 - 2 Miles");
            lstTravel.Items.Add("3 - 5 Miles");
            lstTravel.Items.Add("5- 10 Miles");
            lstTravel.Items.Add("10 - 20 Miles"); - livingston
            lstTravel.Items.Add("20 - 30 Miles"); - bathgate
            */

            Volunteers.Add(new Volunteer("Deborah Barnard", "deborahBarnard@gmail.com", "Edinburgh", "deborahpass",  skillsSamples1, "1 - 2 Miles"));
            Volunteers.Add(new Volunteer("Billy Bobb", "billyBobb@gmail.com", "Bathgate", "billypass", skillsSamples2, "3 - 5 Miles"));//bathgate only
            Volunteers.Add(new Volunteer("Bobby McFarlane", "bobbyMcfarlane@gmail.com", "Bathgate", "bobbypass", skillsSamples2, "20 - 30 Miles")); //all
            Volunteers.Add(new Volunteer("Lilly Lavish", "lillyLavish@gmail.com", "Livingston", "lillypass",skillsSamples1, "1 - 2 Miles")); //livingston only
            Volunteers.Add(new Volunteer("Leslie Johnson", "Leslie Johnson@gmail.com", "Livingston","lesliepass", skillsSamples2, "20 - 30 Miles"));//all
            Volunteers.Add(new Volunteer("Elijah Wood", "elijahWood@gmail.com", "Edinburgh","elijahpass", skillsSamples1, "10 - 20 Miles"));//Edinburgh and livingston
            Volunteers.Add(new Volunteer("Connie Wringe", "connieWringe@gmail.com", "Edinburgh", "conniepass", skillsSamples1, "1-2 Miles"));//Edinburgh only

            return Volunteers;
        }


        private void ButtonLogIn_Click(object sender, RoutedEventArgs e)
        {
            string username = inputUsername.Text;
            string password = inputPassword.Text;


            //create cases for client-volunteer-manager-administrator log in

            foreach (Client tempClient in ClientBase)
            {
                if (tempClient.Email == username)
                {
                    if (tempClient.Password == password)
                    {
                        FinalWelcomeScreen newWin = new FinalWelcomeScreen(tempClient);
                        newWin.Show();
                        this.Close();
                    }
                }
                else
                {
                    lblError.Visibility = Visibility.Visible;
                    lbl1.Visibility = Visibility.Visible;
                    lbl2.Visibility = Visibility.Visible;
                }
            }//if client logs in

            foreach (Volunteer tempVolunteer in VolunteerBase)
            {
                if (tempVolunteer.Email == username)
                {
                    if (tempVolunteer.Password == password)
                    {
                        FinalWelcomeScreen newWin = new FinalWelcomeScreen(tempVolunteer);
                        newWin.Show();
                        this.Close();
                    }
                }
                else
                {
                    lblError.Visibility = Visibility.Visible;
                    lbl1.Visibility = Visibility.Visible;
                    lbl2.Visibility = Visibility.Visible;
                }
            }//if volunteer logs in

            if (username == Manager.Email && password == Manager.Password)
            {
                AccessFeedbackMainWindow newWin = new AccessFeedbackMainWindow(Manager);
                newWin.Show();
                this.Close();
            }
            else if (username == Administrator.Email && password == Administrator.Password)
            {
                AccessFeedbackMainWindow newWin = new AccessFeedbackMainWindow(Administrator);
                newWin.Show();
                this.Close();
            }//if manager or administrator logs in
            else
            {
                lblError.Visibility = Visibility.Visible;
                lbl1.Visibility = Visibility.Visible;
                lbl2.Visibility = Visibility.Visible;
            }//if incorrect details are entered

        }

        private void buttonSignUp_Click(object sender, RoutedEventArgs e)
        {
            SignUpMainWindow newWin = new SignUpMainWindow();
            newWin.Show();
            this.Close();
        }


    }


}

