﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MyClassLibrary;




namespace ProvideFeedback
{
    /// <summary>
    /// Interaction logic for FeedbackWindow.xaml
    /// </summary>
    public partial class FeedbackWindow : Window
    {
        //declare some class wide object variables
        Visit TempVisit = new Visit();
        Client LoggedInClient = new Client();
        Volunteer LoggedInVolunteer = new Volunteer();

        public FeedbackWindow(Visit Visit, Volunteer Volunteer) //volunteer view
        {
            InitializeComponent();
            LoggedInVolunteer = Volunteer;
            labelUpload.Visibility = Visibility.Hidden;

            TempVisit = Visit;

            lblVisit.Content = VolunteerStringList(TempVisit);//shows volunteer version of Visit details

        }//volunteer view

        public FeedbackWindow(Visit Visit, Client Client) //client view
        {
            InitializeComponent();
            LoggedInClient = Client;

            TempVisit = Visit;

            lblVisit.Content = ClientStringList(TempVisit);//shows client version of Visit details

        }//client view

        public string VolunteerStringList(Visit Visit)
        {
            string output = "";

            output += "Visit with " + Visit.Client.Name + " on " + Visit.Date;

            return output;
        }//for display label
        public string ClientStringList(Visit Visit)
        {
            string output = "";

            output += "Visit with " + Visit.Volunteer.Name + " on " + Visit.Date;

            return output;
        }//for display label

        private void ButtonCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void ButtonSubmit_Click(object sender, RoutedEventArgs e)
        {
            string feedback = "";
            string photo = "";

            //if statements to check if inputs are null
            if (inputFeedback.Text == null)
            {
                feedback = "Not supplied";
            } else
            {
                feedback = inputFeedback.Text;
            }

            if (inputPhoto.Text == null)
            {
                photo = "Not supplied";
            }
            else
            {
                photo = inputPhoto.Text;
            }
            
            if(LoggedInClient.UserID != null)//client view
            {
                TempVisit.ClientFeedback.CompleteFeedback(feedback, photo);
                Visit CompleteVisit = new Visit(TempVisit); //for storage

                //pass completed Visit to final confirmation window
                FinalConfirmation newWin = new FinalConfirmation(CompleteVisit, LoggedInClient);
                newWin.Show();

                this.Close();

            } else if(LoggedInVolunteer.UserID != null)//volunteer view
            {
                TempVisit.VolunteerFeedback.CompleteFeedback(feedback, photo);
                Visit CompleteVisit = new Visit(TempVisit); //for storage

                //pass completed Visit to final confirmation window
                FinalConfirmation newWin = new FinalConfirmation(CompleteVisit, LoggedInVolunteer);
                newWin.Show();

                this.Close();
            }//end of if/else statements 
          
        }//end of button click

        private void buttonUpload_Click(object sender, RoutedEventArgs e)
        {
            labelUpload.Visibility = Visibility.Visible; //alerts so simulation of succcessful photo upload

        }
    }//end of window class
}
