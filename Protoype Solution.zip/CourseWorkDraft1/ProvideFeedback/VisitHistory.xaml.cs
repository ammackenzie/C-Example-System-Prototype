﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MyClassLibrary;

namespace ProvideFeedback
{
    /// <summary>
    /// Interaction logic for VisitHistory.xaml
    /// </summary>
    public partial class VisitHistory : Window
    {
        //declare some class-wide object variables
        List<Visit> VisitHistoryDetails = new List<Visit>();
        Client LoggedInClient = new Client();
        Volunteer LoggedInVolunteer = new Volunteer();
        
        public VisitHistory(Client Client) //client logged in
        {
            InitializeComponent();
            LoggedInClient = Client;
            //generate sample client or volunteers

            Volunteer Volunteer1 = new Volunteer("Todd Bricks", "toddBricks@gmail.com");
            Volunteer Volunteer2 = new Volunteer("Billy Bobb", "billyBobb@gmail.com");

            //generate some sample visit instances
            string photo = "/Photos/1234.jpg";

            Visit Visit1 = new Visit(LoggedInClient, Volunteer1, "12/11/19", "10:45", "Great performance, good chat", "Not provided", photo);
            Visit Visit2 = new Visit(LoggedInClient, Volunteer2, "14/11/19", "09:45");
            Visit Visit3 = new Visit(LoggedInClient, Volunteer1, "15/11/19", "11:45");

            //add visits to list
            VisitHistoryDetails.Add(Visit1);
            VisitHistoryDetails.Add(Visit2);
            VisitHistoryDetails.Add(Visit3);
            
            string detailsString = "";

            foreach (Visit V in VisitHistoryDetails)
            {
                detailsString += VisitToString(V);
                detailsString += "\n";
            }//populate details string

            scrollHistory.Content = detailsString; //display details string

            string visitsNeedingFeedback = "";

            foreach (Visit V in VisitHistoryDetails)
            {
                if (V.ClientFeedback.MissingFeedback())
                {
                    visitsNeedingFeedback += VisitToString(V);
                    visitsNeedingFeedback += "\n";
                    comboVisits.Items.Add(ClientStringList(V)); //add list version to comboBox
                }//ppopulate visitsNeedingFeedback string
            }

            comboVisits.SelectedIndex = 0;

            scrollFeedback.Content = visitsNeedingFeedback; //displays only visits lacking client feedback
        }//end of Volunteer constructor

        public VisitHistory(Volunteer Volunteer) //volunteer logged in
        {
            InitializeComponent();
            LoggedInVolunteer = Volunteer;

            //generate sample client or  volunteers
            Client Client1 = new Client("John Hamm", "johnHamm@gmail.com");
            Client Client2 = new Client("Sarah Silverman", "sarahSilverman@gmail.com");
            Client Client3 = new Client("Pepe Silvia", "pepeSilvia@gmail.com");


            //generate some sample visit instances
            string photo = "/Photos/1236.jpg";


            Visit Visit1 = new Visit(Client1, LoggedInVolunteer, "09/08/19", "10:45", "Punctual and attentive", "Not provided", "Not provided");
            Visit Visit2 = new Visit(Client2, LoggedInVolunteer, "04/09/19", "10:45", "Not provided", "Client could have been better", photo);
            Visit Visit3 = new Visit(Client1, LoggedInVolunteer, "15/11/19", "11:45");
            Visit Visit4 = new Visit(Client3, LoggedInVolunteer, "08/08/19", "9:30", "Don't believe that they exist", "Not provided", photo);

            //add sample visits to Visit List
            VisitHistoryDetails.Add(Visit1);
            VisitHistoryDetails.Add(Visit2);
            VisitHistoryDetails.Add(Visit3);
            VisitHistoryDetails.Add(Visit4);


            string detailsString = "";

            foreach (Visit V in VisitHistoryDetails)
            {
                detailsString += VisitToString(V);
                detailsString += "\n";
            }//populate details string

            scrollHistory.Content = detailsString; //displays full details of all visits

            string visitsNeedingFeedback = "";

            foreach (Visit V in VisitHistoryDetails)
            {
                if (V.VolunteerFeedback.MissingFeedback())
                {
                    visitsNeedingFeedback += VisitToString(V);
                    visitsNeedingFeedback += "\n";
                    comboVisits.Items.Add(VolunteerStringList(V)); //add list version to comboBox
                }//populate visitsNeedingFeedback string
            }

            comboVisits.SelectedIndex = 0;

            scrollFeedback.Content = visitsNeedingFeedback; //diaplays only visits needing feedback
        }//end of Client constructor

        public string VisitToString(Visit Visit)//returns string version of saved Visit object details
        {
            string output = "";
            
            output += "\nClient: " + Visit.Client.Name + "\n";
            output += "Volunteer: " + Visit.Volunteer.Name + "\n";
            output += "Date: " + Visit.Date + ", Time: " + Visit.Time + "\n";
            output += "Client Feedback: \n" + Visit.ClientFeedback.UserFeedback + "\n";
            output += "Client Photo: \n" + Visit.ClientFeedback.PhotoAddress + "\n";
            output += "Volunteer Feedback: \n" + Visit.VolunteerFeedback.UserFeedback + "\n";
            output += "Volunteer Photo: \n" + Visit.VolunteerFeedback.PhotoAddress + "\n_________________________________________";
            
            return output;
        }//end of VisitToString

        public string ClientStringList(Visit Visit)//returns list version of Visit details for Client view
        {
            string output = "";

            output += "Visit with " + Visit.Volunteer.Name + " on " + Visit.Date;

            return output;
        }//for display in combobox

        public string VolunteerStringList(Visit Visit)//returns list version of Visit details for Client view
        {
            string output = "";

            output += "Visit with " + Visit.Client.Name + " on " + Visit.Date;

            return output;
        }//for display in combobox

        private void ButtonExit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void ButtonFeedback_Click(object sender, RoutedEventArgs e)
        {
            if(comboVisits.SelectedItem == null)
            {
                lblError.Visibility = Visibility.Visible;
            }
            else
            {
                string selectedVisit = comboVisits.SelectedValue.ToString();

                Visit TempVisit = new Visit(); 

                if (LoggedInClient.UserID != null) //client view
                {
                    foreach (Visit V in VisitHistoryDetails)
                    {
                        if (selectedVisit.Contains(V.Volunteer.Name) && selectedVisit.Contains(V.Date))
                        {
                            TempVisit = V;//ensures selected Visit is stored as class-wide TempVisit
                        }
                    }
                    FeedbackWindow newWinClient = new FeedbackWindow(TempVisit, LoggedInClient);
                    newWinClient.Show();
                    this.Close();
                }
                else if (LoggedInVolunteer.UserID != null) //volunteer view
                {
                    foreach (Visit V in VisitHistoryDetails)
                    {
                        if (selectedVisit.Contains(V.Client.Name) && selectedVisit.Contains(V.Date))
                        {
                            TempVisit = V;//ensures selected Visit is stored as class-wide TempVisit
                        }
                    }
                    FeedbackWindow newWinVolunteer = new FeedbackWindow(TempVisit, LoggedInVolunteer);
                    newWinVolunteer.Show();
                    this.Close();
                }
            }//end of if/else statements

        }//end of button click
    }//end of window class
}


