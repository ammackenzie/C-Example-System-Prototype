﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MyClassLibrary;

namespace ProvideFeedback
{
    /// <summary>
    /// Interaction logic for FinalConfirmation.xaml
    /// </summary>
    public partial class FinalConfirmation : Window
    {
        public FinalConfirmation(Visit Visit, Client Client)//client view
        {
            InitializeComponent();
            lblOutput.Content = VisitToString(Visit);
        }

        public FinalConfirmation(Visit Visit, Volunteer Volunteer)//volunteer view
        {
            InitializeComponent();

            lblOutput.Content = VisitToString(Visit);
        }

        public string VisitToString(Visit Visit)
        {
            string output = "";

            output += "Client: " + Visit.Client.Name + "\n";
            output += "Volunteer: " + Visit.Volunteer.Name + "\n";
            output += "Date: " + Visit.Date + ", Time: " + Visit.Time + "\n";
            output += "Client Feedback: " + Visit.ClientFeedback.UserFeedback + "\n";
            output += "Client Photo: " + Visit.ClientFeedback.PhotoAddress + "\n";
            output += "Volunteer Feedback: " + Visit.VolunteerFeedback.UserFeedback + "\n";
            output += "Volunteer Photo: " + Visit.VolunteerFeedback.PhotoAddress + "\n";

            return output;
        }

        private void ButtonExit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }//end of window class
}
